const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();

app.use(express.json());
app.use(express.static('public'));

const db = new sqlite3.Database('./database.db');

db.serialize(() => {

    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT,
        fullName TEXT,
        balance REAL DEFAULT 0
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        type TEXT,
        amount REAL,
        merchant TEXT,
        date TEXT
    )`);

    // CLEAR OLD DATA (important for demo)
    db.run(`DELETE FROM users`);
    db.run(`DELETE FROM transactions`);

    // CREATE USER
    db.run(
        `INSERT INTO users (username, password, fullName, balance)
      VALUES (?, ?, ?, ?)`,
      ["kristen222", "Kristenschuch222", "Kristen Schuch", 0],
        function () {

            const userId = this.lastID;

            const merchants = [
                "Amazon", "Netflix", "Walmart",
                "Apple Store", "Uber", "Restaurant",
                "Salary", "ATM Withdrawal"
            ];


            const demoTx = [
                { type: "deposit", amount: 58650.50, merchant: " Wire Transfer Incoming frm Unin clearance", date: "2026-01-04" },
                { type: "deposit", amount: 15800, merchant: "Check Deposit", date: "2025-11-22" },
                { type: "transfer", amount: 239, merchant: "Amazon Purchase", date: "2026-02-01" },
                { type: "transfer", amount: 1500, merchant: "Apple Store", date: "2026-03-05" },
                { type: "transfer", amount: 438.3, merchant: "Mission lane payment", date: "2026-03-19" },
                { type: "transfer", amount: 900, merchant: " ATM Cash withdraw", date: "2026-03-15" },
                { type: "deposit", amount: 1100, merchant: "Ext Trans from X1bs", date: "2026-03-22" },
                { type: "transfer", amount: 150, merchant: "Wallgreen", date: "2026-04-12" },
                { type: "transfer", amount: 2400, merchant: "Apple Store", date: "2026-03-19" },
                { type: "transfer", amount: 650.50, merchant: "ATM Cash withdraw", date: "2026-04-10" }
                
                
            ];
            
            let balance = 0;
            
            demoTx.forEach(tx => {
                if (tx.type === "deposit") balance += tx.amount;
                else balance -= tx.amount;
            
                db.run(
                    `INSERT INTO transactions (user_id, type, amount, merchant, date)
                     VALUES (?, ?, ?, ?, ?)`,
                    [userId, tx.type, tx.amount, tx.merchant, tx.date]
                );
            });
            
            db.run(`UPDATE users SET balance=? WHERE id=?`, [balance, userId]);

            db.run(`UPDATE users SET balance=? WHERE id=?`, [balance, userId]);
        }
    );
});

// LOGIN
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get(
        `SELECT * FROM users WHERE username=? AND password=?`,
        [username, password],
        (err, user) => {
            if (!user) return res.json({ error: "Invalid login" });
            res.json(user);
        }
    );
});

// DASHBOARD
app.get('/dashboard/:id', (req, res) => {
    db.get(`SELECT * FROM users WHERE id=?`, [req.params.id], (err, user) => {
        db.all(`SELECT * FROM transactions WHERE user_id=?`, [req.params.id], (err, txs) => {
            res.json({ user, transactions: txs });
        });
    });
});
// DEPOSIT
app.post('/deposit', (req, res) => {
    const { userId, amount } = req.body;

    const amt = Number(amount);

    db.run(`UPDATE users SET balance = balance + ? WHERE id=?`, [amt, userId]);

    db.run(
        `INSERT INTO transactions (user_id, type, amount, merchant, date)
         VALUES (?, 'deposit', ?, 'Cash Deposit', datetime('now'))`,
        [userId, amt]
    );

    res.json({ success: true });
});
// TRANSFER
app.post('/transfer', (req, res) => {
    const { fromUser, amount } = req.body;

    const amt = Number(amount);

    db.run(`UPDATE users SET balance = balance - ? WHERE id=?`, [amt, fromUser]);

    db.run(
        `INSERT INTO transactions (user_id, type, amount, merchant, date)
         VALUES (?, 'transfer', ?, 'Transfer Out', datetime('now'))`,
        [fromUser, amt]
    );

    res.json({ success: true });
});

app.listen(3000, () => console.log("http://localhost:3000"));