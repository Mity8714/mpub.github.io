let chart;

async function login() {
  const usernameValue = document.getElementById('username').value;
  const passwordValue = document.getElementById('password').value;

  const res = await fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: usernameValue, password: passwordValue })
  });

  const data = await res.json();

  if (data.error) {
      alert("Login failed");
      return;
  }

  localStorage.setItem('userId', data.id);
  window.location.href = "dashboard.html";
}

async function loadDashboard() {
    const userId = localStorage.getItem('userId');

    const res = await fetch(`/dashboard/${userId}`);
    const data = await res.json();

    balance.innerText = "$"+data.user.balance;
    document.getElementById('cardName').innerText =
    data.user.username;
    document.getElementById('cardName').innerText =
    data.user.fullName;

    document.querySelectorAll('#cardName').forEach(el => {
        el.innerText = data.user.fullName;
    });
    
    document.getElementById('profileName').innerText =
        data.user.fullName;
    
    document.getElementById('accountNumber').innerText =
        "00" + data.user.id + "78294521";

    document.getElementById('profileName').innerText =
    data.user.fullName;

    // generate fake account number
    document.getElementById('accountNumber').innerText =
    "00" + data.user.id + "78294521";

    const list = transactions;
    list.innerHTML = "";

    let deposits=0, transfers=0;

    data.transactions.forEach(tx=>{
        const li = document.createElement('li');
        const isDeposit = tx.type==="deposit";

        if(isDeposit) deposits+=tx.amount;
        else transfers+=tx.amount;

        li.innerHTML = `
    <div>
        <strong>${tx.merchant}</strong><br>
        <small>${new Date(tx.date).toLocaleDateString()}</small>
    </div>

    <div style="text-align:right; color:${isDeposit ? '#22c55e' : '#ef4444'}">
        ${isDeposit ? '+' : '-'}$${tx.amount}
    </div>
`;

li.onclick = () => viewTransaction(tx);
list.appendChild(li);
    });

    renderChart(deposits, transfers);
}

function logout() {
    localStorage.removeItem('userId');
    window.location.href = "login.html";
}

function renderChart(dep, trans){
    const ctx = financeChart.getContext('2d');

    if(chart) chart.destroy();

    chart = new Chart(ctx,{
        type:'doughnut',
        data:{
            labels:['Deposits','Transfers'],
            datasets:[{
                data:[dep,trans],
                backgroundColor:['#22c55e','#ef4444']
            }]
        }
    });
}

async function deposit() {
    alert("Unable to deposit: Account restricted");
}

async function transfer() {
    alert("Unable to transfer: Account restricted");
}

function toggleDeposit(){ depositBox.classList.toggle('hidden'); }
function toggleTransfer(){ transferBox.classList.toggle('hidden'); }

if(location.pathname.includes("dashboard")) loadDashboard();
function toggleDeposit() {
    document.getElementById('depositBox').classList.toggle('hidden');
    document.getElementById('transferBox').classList.add('hidden');
}

function toggleTransfer() {
    document.getElementById('transferBox').classList.toggle('hidden');
    document.getElementById('depositBox').classList.add('hidden');
}
function deposit() {
    showPopup("Unable to deposit: Account restricted");
}

function transfer() {
    showPopup("Unable to transfer: Account restricted");
}

document.querySelector('.card-number').innerText =
    "•••• •••• •••• " + String(data.user.id).padStart(4, '0');
    document.getElementById('cardName').innerText =
    data.user.fullName;

function showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        document.getElementById(screenId).classList.add('active');
    }

    function showPopup(message) {
        const popup = document.getElementById('popup');
        const text = document.getElementById('popupText');
    
        if (!popup || !text) {
            alert(message); // fallback if popup missing
            return;
        }
    
        text.innerText = message;
        popup.classList.remove('hidden');
    
        setTimeout(() => {
            popup.classList.add('hidden');
        }, 3000);
    }

    function openDeposit() {
        window.location.href = "deposit.html";
    }
    
    function openTransfer() {
        window.location.href = "transfer.html";
    }
    
    function goBack() {
        window.location.href = "dashboard.html";
    }
function viewTransaction(tx) {
        localStorage.setItem('selectedTx', JSON.stringify(tx));
        window.location.href = "transaction.html";
    }
    if (window.location.pathname.includes("transaction.html")) {
        const tx = JSON.parse(localStorage.getItem('selectedTx'));
    
        if (tx) {
            document.getElementById('txMerchant').innerText = tx.merchant;
            document.getElementById('txAmount').innerText =
                (tx.type === "deposit" ? "+" : "-") + "$" + tx.amount;
    
            document.getElementById('txDate').innerText =
                new Date(tx.date).toLocaleString();
    
            document.getElementById('txType').innerText = tx.type.toUpperCase();
    
            // fake reference ID
            document.getElementById('txRef').innerText =
                "MPUB-" + Math.floor(Math.random() * 1000000000);
        }
    }
    function toggleMenu() {

        const menu = document.getElementById('sideMenu');
        const overlay = document.getElementById('overlay');
    
        menu.classList.toggle('open');
        overlay.classList.toggle('hidden');
    }

    function toggleNotifications() {

        document.getElementById('notifPanel')
            .classList.toggle('hidden');
    }